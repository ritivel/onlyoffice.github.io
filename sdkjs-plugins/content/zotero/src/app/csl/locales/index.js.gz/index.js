// @ts-check

export { LocalesManager } from "./locales-manager.js";
