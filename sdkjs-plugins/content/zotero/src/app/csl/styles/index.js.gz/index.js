// @ts-check

export { CslStylesManager } from "./styles-manager.js";
